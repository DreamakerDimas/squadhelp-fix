Запуск:
bash start-dev.sh
